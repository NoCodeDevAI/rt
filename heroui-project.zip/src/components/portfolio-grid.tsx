import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, Image, Modal, ModalContent, ModalHeader, ModalBody, ModalFooter, Button, useDisclosure, Chip, Divider } from "@heroui/react";
import { Icon } from "@iconify/react";

interface Project {
  id: number;
  title: string;
  category: string;
  imageUrl: string;
  description: string;
  tags: string[];
}

const projects: Project[] = [
  {
    id: 1,
    title: "Eco Fashion Brand Identity",
    category: "Branding",
    imageUrl: "https://img.heroui.chat/image/ai?w=600&h=400&u=2",
    description: "Complete brand identity design for a sustainable fashion company, including logo design, color palette development, typography selection, and comprehensive brand guidelines to ensure consistent application across all touchpoints.",
    tags: ["Logo Design", "Brand Guidelines", "Sustainability"]
  },
  {
    id: 2,
    title: "Wellness App UI Design",
    category: "UI Design",
    imageUrl: "https://img.heroui.chat/image/ai?w=600&h=400&u=3",
    description: "User interface design for a wellness tracking mobile application with a focus on accessibility and user experience. The project included user research, wireframing, prototyping, and final UI design with a comprehensive component library.",
    tags: ["Mobile App", "UI/UX", "Prototyping"]
  },
  {
    id: 3,
    title: "Summer Collection Campaign",
    category: "Marketing",
    imageUrl: "https://img.heroui.chat/image/ai?w=600&h=400&u=4",
    description: "Digital marketing campaign assets including social media graphics, email templates, and landing page design for a fashion brand's summer collection launch, resulting in a 40% increase in online engagement.",
    tags: ["Social Media", "Email Design", "Campaign"]
  },
  {
    id: 4,
    title: "Tech Startup Website Redesign",
    category: "Web Design",
    imageUrl: "https://img.heroui.chat/image/ai?w=600&h=400&u=5",
    description: "Complete website redesign for a tech startup, focusing on modern aesthetics and improved user flow. The project included information architecture, wireframing, visual design, and collaboration with developers for implementation.",
    tags: ["Web Design", "UX Design", "Responsive"]
  },
  {
    id: 5,
    title: "Organic Skincare Packaging",
    category: "Packaging",
    imageUrl: "https://img.heroui.chat/image/ai?w=600&h=400&u=6",
    description: "Sustainable packaging design for an organic skincare line, incorporating eco-friendly materials and elegant typography. The design focused on communicating the brand's natural ingredients and environmental commitment.",
    tags: ["Packaging", "Sustainability", "Print Design"]
  },
  {
    id: 6,
    title: "Fashion Magazine Layout",
    category: "Print",
    imageUrl: "https://img.heroui.chat/image/ai?w=600&h=400&u=7",
    description: "Magazine layout and editorial design for a quarterly fashion publication, featuring custom typography and photo editing. The project included cover design, feature spreads, and establishing a cohesive visual language throughout.",
    tags: ["Editorial", "Typography", "Layout"]
  }
];

const categories = ["All", "Branding", "UI Design", "Marketing", "Web Design", "Packaging", "Print"];

export const PortfolioGrid = () => {
  const {isOpen, onOpen, onOpenChange} = useDisclosure();
  const [selectedProject, setSelectedProject] = React.useState<Project | null>(null);
  const [activeCategory, setActiveCategory] = useState("All");

  const handleProjectClick = (project: Project) => {
    setSelectedProject(project);
    onOpen();
  };

  const filteredProjects = activeCategory === "All" 
    ? projects 
    : projects.filter(project => project.category === activeCategory);

  return (
    <section id="portfolio" className="py-24 px-4 bg-gradient-to-b from-background to-default-50 dark:from-background dark:to-default-900/20">
      <div className="container mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 text-sm font-medium mb-4">
            <Icon icon="lucide:briefcase" className="text-lg" />
            <span>Portfolio</span>
          </div>
          <h2 className="text-4xl font-bold font-heading mb-4">Featured Projects</h2>
          <p className="text-xl text-default-600 max-w-2xl mx-auto">
            Explore a selection of my recent work across various design disciplines
          </p>
        </motion.div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((category) => (
            <Button
              key={category}
              variant={activeCategory === category ? "solid" : "flat"}
              color={activeCategory === category ? "primary" : "default"}
              radius="full"
              size="sm"
              className="font-medium"
              onPress={() => setActiveCategory(category)}
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Projects Grid */}
        <motion.div layout className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <AnimatePresence>
            {filteredProjects.map((project) => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                layout
                transition={{ duration: 0.4 }}
              >
                <Card
                  isPressable
                  onPress={() => handleProjectClick(project)}
                  className="overflow-hidden h-full transform-gpu transition-all duration-300 hover:shadow-lg dark:hover:shadow-primary-500/10 hover:-translate-y-1"
                >
                  <div className="relative overflow-hidden aspect-[4/3]">
                    <Image
                      removeWrapper
                      alt={project.title}
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                      src={project.imageUrl}
                    />
                    <div className="absolute top-3 right-3">
                      <Chip
                        size="sm"
                        color="primary"
                        variant="flat"
                        className="font-medium"
                      >
                        {project.category}
                      </Chip>
                    </div>
                  </div>
                  <div className="p-5">
                    <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                    <p className="text-default-500 line-clamp-2 mb-4">
                      {project.description.substring(0, 100)}...
                    </p>
                    <div className="flex flex-wrap gap-1">
                      {project.tags.map((tag, index) => (
                        <Chip key={index} size="sm" variant="flat" className="text-xs">
                          {tag}
                        </Chip>
                      ))}
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>

      {/* Project Detail Modal */}
      <Modal 
        size="3xl" 
        isOpen={isOpen} 
        onOpenChange={onOpenChange}
        scrollBehavior="inside"
      >
        <ModalContent>
          {(onClose) => selectedProject && (
            <>
              <ModalHeader className="flex flex-col gap-1">
                <h3 className="text-2xl font-bold">{selectedProject.title}</h3>
                <p className="text-default-500 text-sm">{selectedProject.category}</p>
              </ModalHeader>
              <ModalBody>
                <Image
                  removeWrapper
                  alt={selectedProject.title}
                  className="w-full aspect-[16/9] object-cover rounded-lg mb-4"
                  src={selectedProject.imageUrl}
                />
                <div className="flex flex-wrap gap-1 mb-4">
                  {selectedProject.tags.map((tag, index) => (
                    <Chip key={index} color="primary" variant="flat" className="text-xs">
                      {tag}
                    </Chip>
                  ))}
                </div>
                <Divider className="my-4" />
                <h4 className="text-lg font-semibold mb-2">Project Overview</h4>
                <p className="text-default-600">
                  {selectedProject.description}
                </p>
              </ModalBody>
              <ModalFooter>
                <Button color="default" variant="light" onPress={onClose}>
                  Close
                </Button>
                <Button color="primary" onPress={() => console.log("View case study")}>
                  View Case Study
                </Button>
              </ModalFooter>
            </>
          )}
        </ModalContent>
      </Modal>
    </section>
  );
};