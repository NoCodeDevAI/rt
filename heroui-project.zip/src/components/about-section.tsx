import React from "react";
import { motion } from "framer-motion";
import { Button, Card, Progress, Tabs, Tab } from "@heroui/react";
import { Icon } from "@iconify/react";
import { Canvas } from "@react-three/fiber";
import { Float } from "@react-three/drei";

interface Skill {
  name: string;
  level: number;
  icon: string;
}

const skills: Skill[] = [
  { name: "Adobe Creative Suite", level: 95, icon: "simple-icons:adobe" },
  { name: "Figma", level: 90, icon: "simple-icons:figma" },
  { name: "UI/UX Design", level: 85, icon: "lucide:layout" },
  { name: "Brand Identity", level: 90, icon: "lucide:palette" },
  { name: "Typography", level: 80, icon: "lucide:type" },
  { name: "Motion Design", level: 75, icon: "lucide:video" },
  { name: "Web Design", level: 85, icon: "lucide:globe" },
  { name: "Print Design", level: 80, icon: "lucide:printer" }
];

const experiences = [
  {
    title: "Senior Designer",
    company: "Creative Studio",
    period: "2020 - Present",
    description: "Lead designer for major brand projects, managing client relationships and mentoring junior designers."
  },
  {
    title: "UI Designer",
    company: "Tech Corp",
    period: "2018 - 2020",
    description: "Designed user interfaces for web and mobile applications, collaborating with product and development teams."
  },
  {
    title: "Freelance Designer",
    company: "Self-employed",
    period: "2016 - 2018",
    description: "Provided design services for various clients, specializing in branding and digital design."
  }
];

const education = [
  {
    degree: "Master of Arts in Design",
    school: "Design Institute",
    period: "2014 - 2016"
  },
  {
    degree: "Bachelor of Fine Arts",
    school: "State University",
    period: "2010 - 2014"
  }
];

// 3D icon component
const SkillIcon = ({ position, color }: { position: [number, number, number]; color: string }) => {
  return (
    <Float
      speed={2}
      rotationIntensity={1}
      floatIntensity={1}
    >
      <mesh position={position}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color={color} opacity={0.8} transparent />
      </mesh>
    </Float>
  );
};

export const AboutSection = () => {
  return (
    <section id="about" className="py-24 px-4 bg-default-50 dark:bg-default-900/20 relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute right-0 top-0 w-40 h-40 opacity-20">
        <Canvas>
          <ambientLight intensity={0.5} />
          <directionalLight position={[10, 10, 5]} />
          <SkillIcon position={[0, 0, 0]} color="#1a6af9" />
        </Canvas>
      </div>
      
      <div className="absolute left-0 bottom-0 w-40 h-40 opacity-20">
        <Canvas>
          <ambientLight intensity={0.5} />
          <directionalLight position={[10, 10, 5]} />
          <SkillIcon position={[0, 0, 0]} color="#25a085" />
        </Canvas>
      </div>
      
      <div className="container mx-auto max-w-6xl relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 text-sm font-medium mb-4">
            <Icon icon="lucide:user" className="text-lg" />
            <span>About Me</span>
          </div>
          <h2 className="text-4xl font-bold font-heading mb-4">My Background</h2>
          <p className="text-xl text-default-600 max-w-2xl mx-auto">
            I'm a passionate graphic designer with over 5 years of experience creating meaningful digital experiences that connect brands with their audience.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* About me text and image */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <Card className="p-6 overflow-hidden relative">
              <div className="absolute top-0 right-0 w-32 h-32 bg-primary-100 dark:bg-primary-900/20 rounded-bl-full -mt-8 -mr-8"></div>
              <h3 className="text-2xl font-semibold mb-4 relative z-10">My Approach</h3>
              <p className="text-default-600 mb-4">
                I believe that great design is about solving problems and creating meaningful connections. My approach combines aesthetic excellence with strategic thinking to deliver impactful solutions that resonate with audiences and achieve business goals.
              </p>
              <p className="text-default-600">
                Whether I'm designing a brand identity, a user interface, or marketing materials, I focus on creating work that is not only visually compelling but also purposeful and effective.
              </p>
              
              <div className="mt-8 grid grid-cols-2 gap-4">
                <div className="flex flex-col items-center p-4 bg-content2 rounded-lg">
                  <span className="text-3xl font-bold text-primary-600 dark:text-primary-400">5+</span>
                  <span className="text-default-600">Years Experience</span>
                </div>
                <div className="flex flex-col items-center p-4 bg-content2 rounded-lg">
                  <span className="text-3xl font-bold text-primary-600 dark:text-primary-400">50+</span>
                  <span className="text-default-600">Projects Completed</span>
                </div>
              </div>
            </Card>
            
            <Button
              color="primary"
              variant="flat"
              startContent={<Icon icon="lucide:download" />}
              onPress={() => console.log("Download resume")}
              className="w-full"
            >
              Download Resume
            </Button>
          </motion.div>

          {/* Tabs for Skills, Experience, Education */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <Card className="p-6">
              <Tabs aria-label="About me tabs" color="primary" variant="underlined" classNames={{
                tabList: "gap-6",
                cursor: "bg-primary-500",
                tab: "max-w-fit px-0 h-12"
              }}>
                <Tab 
                  key="skills" 
                  title={
                    <div className="flex items-center gap-2">
                      <Icon icon="lucide:code" />
                      <span>Skills</span>
                    </div>
                  }
                >
                  <div className="mt-4 space-y-6">
                    {skills.map((skill) => (
                      <div key={skill.name} className="space-y-2">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-2">
                            <Icon icon={skill.icon} className="text-primary-500" />
                            <span className="font-medium">{skill.name}</span>
                          </div>
                          <span className="text-sm text-default-500">{skill.level}%</span>
                        </div>
                        <Progress 
                          value={skill.level} 
                          color="primary"
                          size="sm"
                          className="max-w-full"
                        />
                      </div>
                    ))}
                  </div>
                </Tab>
                <Tab 
                  key="experience" 
                  title={
                    <div className="flex items-center gap-2">
                      <Icon icon="lucide:briefcase" />
                      <span>Experience</span>
                    </div>
                  }
                >
                  <div className="mt-4 space-y-6">
                    {experiences.map((exp, index) => (
                      <div key={index} className="relative pl-6 pb-6 border-l border-default-200 dark:border-default-700 last:border-0 last:pb-0">
                        <div className="absolute left-[-8px] top-0 w-4 h-4 rounded-full bg-primary-500"></div>
                        <h4 className="text-lg font-semibold">{exp.title}</h4>
                        <p className="text-primary-600 dark:text-primary-400 font-medium">{exp.company}</p>
                        <p className="text-default-500 text-sm mb-2">{exp.period}</p>
                        <p className="text-default-600">{exp.description}</p>
                      </div>
                    ))}
                  </div>
                </Tab>
                <Tab 
                  key="education" 
                  title={
                    <div className="flex items-center gap-2">
                      <Icon icon="lucide:graduation-cap" />
                      <span>Education</span>
                    </div>
                  }
                >
                  <div className="mt-4 space-y-6">
                    {education.map((edu, index) => (
                      <div key={index} className="relative pl-6 pb-6 border-l border-default-200 dark:border-default-700 last:border-0 last:pb-0">
                        <div className="absolute left-[-8px] top-0 w-4 h-4 rounded-full bg-primary-500"></div>
                        <h4 className="text-lg font-semibold">{edu.degree}</h4>
                        <p className="text-primary-600 dark:text-primary-400 font-medium">{edu.school}</p>
                        <p className="text-default-500 text-sm">{edu.period}</p>
                      </div>
                    ))}
                  </div>
                </Tab>
              </Tabs>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
};